import Utils from "./module/Utils.js";
import WindowManager from "./module/windows/WindowManager.js";
import WindowType from "./module/windows/WindowType.js";
import { _onDragMouseDown, _onDragMouseMove } from "./module/windows/DraggableHijack.js";
Hooks.once('init', async () => {
    Utils.debug('Module initialized.');
    // @ts-ignore
    Draggable.prototype._onDragMouseDown = _onDragMouseDown;
    // @ts-ignore
    Draggable.prototype._onDragMouseMove = _onDragMouseMove;
});
Hooks.once('setup', () => {
    Utils.debug('Setup completed.');
});
Hooks.once('ready', () => {
    Utils.debug('Module ready.');
});
Hooks.on('renderActorSheet', (sheetObj, $sheet, options) => {
    WindowManager.addWindow(sheetObj, $sheet, options, WindowType.ACTOR_SHEET);
});
Hooks.on('closeActorSheet', (sheetObj, $sheet) => {
    WindowManager.removeWindow(sheetObj, $sheet, WindowType.ACTOR_SHEET);
});
