import Utils from "./module/Utils.js";
import ActorSheetWindow from "./module/windows/ActorSheetWindow.js";
Hooks.once('init', async function () {
    Utils.debug('Module initialized.', false);
});
//
//
// Hooks.once('setup', function() {
// 	Utils.debug('Setup complete.', false);
// });
//
//
// Hooks.once('ready', function() {
// 	Utils.debug('Ready.', false);
// });
Hooks.on('renderActorSheet', ActorSheetWindow.hook.bind(ActorSheetWindow));
