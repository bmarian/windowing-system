var WindowType;
(function (WindowType) {
    WindowType[WindowType["ACTOR_SHEET"] = 0] = "ACTOR_SHEET";
})(WindowType || (WindowType = {}));
export default WindowType;
