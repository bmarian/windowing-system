import Utils from "../Utils.js";
class ActorSheet {
    constructor() {
    }
    static getInstance() {
        if (!ActorSheet._instance)
            ActorSheet._instance = new ActorSheet();
        return ActorSheet._instance;
    }
    hook() {
        Utils.debug('ActorSheet hook.');
    }
}
export default ActorSheet.getInstance();
