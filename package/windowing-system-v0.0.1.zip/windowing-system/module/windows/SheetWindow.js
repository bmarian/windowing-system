import GenericWindow from "./GenericWindow.js";
class SheetWindow extends GenericWindow {
}
export default SheetWindow;
