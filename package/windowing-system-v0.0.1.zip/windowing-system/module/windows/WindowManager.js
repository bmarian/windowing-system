import WindowType from "./WindowType.js";
import SheetWindow from "./SheetWindow.js";
class WindowManager {
    constructor() {
        this._windows = [];
    }
    static getInstance() {
        if (!WindowManager._instance)
            WindowManager._instance = new WindowManager();
        return WindowManager._instance;
    }
    _saveSheetWindow(windowObj) {
        const saveData = {
            id: windowObj?.object?._id,
            hasToken: windowObj?.token !== null,
        };
        const exists = this._windows.some(el => el?.id === saveData.id && el?.hasToken === saveData.hasToken);
        if (!exists)
            this._windows.push(saveData);
        return exists;
    }
    _deleteSheetWindow(windowObj) {
        const searchData = {
            id: windowObj?.object?._id,
            hasToken: windowObj?.token !== null,
        };
        this._windows = this._windows.filter(el => !(el?.id === searchData.id && el?.hasToken === searchData.hasToken));
    }
    addWindow(windowObj, $window, options, type) {
        let window;
        switch (type) {
            case WindowType.ACTOR_SHEET: {
                // const windowExists = this._saveSheetWindow(windowObj);
                // if (!windowExists) window = new SheetWindow(windowObj, $window, options);
                window = new SheetWindow(windowObj, $window, options);
                break;
            }
        }
        window = null;
        // Utils.debug('WM window add', this._windows);
    }
    removeWindow(windowObj, $window, type) {
        switch (type) {
            case WindowType.ACTOR_SHEET: {
                // this._deleteSheetWindow(windowObj);
                break;
            }
        }
        // Utils.debug('WM window remove', this._windows);
    }
}
export default WindowManager.getInstance();
