class Defaults {
    constructor() {
        this._defaultClasses = {
            CLOSE_BUTTON_QRY: '.close',
            WINDOW_HEADER_QRY: '.window-header',
            WINDOW_TITLE_QRY: '.window-title',
            CANVAS_QRY: '#board',
            SIDEBAR_QRY: '#sidebar',
            NAVIGATION_QRY: '#navigation',
            CONTROLS_QRY: '#controls',
            PLAYERS_QRY: '#players',
            RESIZABLE_HANDLE_QRY: '.window-resizable-handle',
        };
    }
    static getInstance() {
        if (!Defaults._instance)
            Defaults._instance = new Defaults();
        return Defaults._instance;
    }
    /**
     * Returns a list of default css classes, used to identify elements in the interface
     */
    getDefaultClasses() {
        return this._defaultClasses;
    }
}
export default Defaults.getInstance();
